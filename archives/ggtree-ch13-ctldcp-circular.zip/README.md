# 鸡CTLDcp环形树与禽特异扩张

场景一：做完免疫受体 / OLR / CYP 等基因家族的跨物种树，想看鸡（或鱼、植物）的拷贝是一对一挂在哺乳动物直系同源旁边，还是在某一亚家族里堆成一块“物种特异扩张”。环形 + 按物种改线型/颜色 + 扇形高亮就是为这个问题设计的。场景二：论文里要同时标出 Group II vs Group V，并给扩张支写上 Subgroup A/B。tip 很多（>50）时矩形树会拉得很长，环形更省版面。不适合：只有一两个物种、或主要想展示采样年/分化时间（用矩形时间树）。本图用 tip 前缀 ch/h/p 区分物种；换成自己的树时要先统一命名，否则 groupOTU 会分错。

复刻 YuLab treedata-book Figure 13.3 / Larsen et al. 2019 Figure 1。树来自 TDbook，未重跑基因家族建树。

This module is an Open Figure Modules submission prepared from a Local Published release. SFL does not execute the code.
